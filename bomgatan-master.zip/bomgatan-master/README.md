# bomgatan
Digital services for Bomgatan

An adaptation of [findit](https://findit.chalmers.it/)
find it on github [here](https://github.com/cthit/findIT)

